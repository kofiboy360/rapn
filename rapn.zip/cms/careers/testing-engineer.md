---
f_job-type: Part Time
f_job-role: San Francisco
title: Testing Engineer
f_job-description: |-
  Remote, India , 4 to 5 Years Of Experience
  Department: Website Design
  5 Positions Available.
f_salary-2: $30000 Per Anum
slug: testing-engineer
updated-on: '2021-08-05T19:51:14.944Z'
created-on: '2021-07-17T12:20:56.034Z'
published-on: '2024-08-23T13:42:04.406Z'
f_job-requirement: >-
  Design & Create highly engaging industry-related content in both photo, gif &
  video format  

  ‍


  Publish Posts on various social media channels Promote content on social
  networks and monitor engagement (e.g. comments and shares) Research
  industry-related topics Editing audio and sound design on projects  

  Engage in opportunities to develop original content and concepts for web and
  mobile  

  ‍


  Create motion graphics and animations using 2D and 3D applications for
  marketing and promotional usage. manage the day-to-day handling of all social
  media channels such as LinkedIn, Facebook, Twitter, Pinterest, Instagram,
  Tiktok and YouTube, adapting content to suit different channels
f_job-responsibility: >-
  Design & Create highly engaging industry-related content in both photo, gif &
  video format  

  ‍


  Publish Posts on various social media channels Promote content on social
  networks and monitor engagement (e.g. comments and shares) Research
  industry-related topics Editing audio and sound design on projects  

  Engage in opportunities to develop original content and concepts for web and
  mobile  

  ‍


  Create motion graphics and animations using 2D and 3D applications for
  marketing and promotional usage. manage the day-to-day handling of all social
  media channels such as LinkedIn, Facebook, Twitter, Pinterest, Instagram,
  Tiktok and YouTube, adapting content to suit different channels
layout: '[careers].html'
tags: careers
---

Design & Create highly engaging industry-related content in both photo, gif & video format  
‍

Publish Posts on various social media channels Promote content on social networks and monitor engagement (e.g. comments and shares) Research industry-related topics Editing audio and sound design on projects  
Engage in opportunities to develop original content and concepts for web and mobile  
‍

Create motion graphics and animations using 2D and 3D applications for marketing and promotional usage. manage the day-to-day handling of all social media channels such as LinkedIn, Facebook, Twitter, Pinterest, Instagram, Tiktok and YouTube, adapting content to suit different channels
