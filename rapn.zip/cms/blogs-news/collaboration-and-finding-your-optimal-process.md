---
f_featured: false
title: Collaboration and finding your optimal process
f_post-summary: >-
  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur sit amet
  eros blandit, hendrerit elit et.
f_main-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cb5bdfbb2507576b084991_enterprise%2015.png
  alt: null
f_thumbnail-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cb5bdfbb2507576b084991_enterprise%2015.png
  alt: null
slug: collaboration-and-finding-your-optimal-process
updated-on: '2024-08-25T16:29:26.673Z'
created-on: '2021-07-15T15:38:27.044Z'
published-on: '2024-08-25T16:30:03.062Z'
f_author-details: cms/author/selby-johnson.md
f_alt-text-for-image: Team work
layout: '[blogs-news].html'
tags: blogs-news
---

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice and tone for error messages.

Transform Your Idea Into Reality
--------------------------------

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice.

![](https://uploads-ssl.webflow.com/66c890177ca4688e94a34cb3/66cb5be63d9513e78301e0e3_66c890177ca4688e94a34cc1_blog-thumbnail-4.jpeg)

### Transform Your Idea Into Reality

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.

*   Writing UX copies can be a little frustrating and confusing
*   sometimes we are unsure about how to get the right word
*   The plugin is called the Ghost UXWriter and has a set of UX copies cataloged

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice.

#### Transform Your Idea Into Reality

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.
