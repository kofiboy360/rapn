---
f_featured: false
title: Helping the next generation of leaders
f_post-summary: >-
  Authentic leadership critical for business growth – Telecel’s GM for
  Commercial Operations
f_main-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cb5b2b1f6730bac6bcdaf2_medical.png
  alt: null
f_thumbnail-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cb5b2b1f6730bac6bcdaf2_medical.png
  alt: null
slug: helping-the-next-generation-of-leaders
updated-on: '2024-08-25T16:26:25.953Z'
created-on: '2021-07-15T15:38:50.819Z'
published-on: '2024-08-25T16:30:03.062Z'
f_author-details: cms/author/timmothy-burns.md
f_alt-text-for-image: A woman teaching her daughter in laptop
layout: '[blogs-news].html'
tags: blogs-news
---

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice and tone for error messages.

Transform Your Idea Into Reality
--------------------------------

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice.

![](https://uploads-ssl.webflow.com/66c890177ca4688e94a34cb3/66cb5b31796c0ab0a82a0320_66c890177ca4688e94a34cbd_blog-thumbnail-3.jpeg)

### Transform Your Idea Into Reality

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.

*   Writing UX copies can be a little frustrating and confusing
*   sometimes we are unsure about how to get the right word
*   The plugin is called the Ghost UXWriter and has a set of UX copies cataloged

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice.

#### Transform Your Idea Into Reality

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.
