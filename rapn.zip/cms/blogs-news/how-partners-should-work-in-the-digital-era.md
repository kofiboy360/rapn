---
f_featured: false
f_post-summary: >-
  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur sit amet
  eros blandit, hendrerit elit et.
title: How partners should work in the digital era
slug: how-partners-should-work-in-the-digital-era
updated-on: '2024-08-25T16:29:43.653Z'
created-on: '2021-07-15T09:13:06.934Z'
published-on: '2024-08-25T16:30:03.062Z'
f_main-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cb5bed609ab9d862b42141_SIC_Life_.jpg
  alt: null
f_thumbnail-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cb5bed609ab9d862b42141_SIC_Life_.jpg
  alt: null
f_author-details: cms/author/timmothy-burns.md
f_alt-text-for-image: Two professionally dressed persons
layout: '[blogs-news].html'
tags: blogs-news
---

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice and tone for error messages.

Transform Your Idea Into Reality
--------------------------------

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice.

![](https://uploads-ssl.webflow.com/66c890177ca4688e94a34cb3/66cb5bf74d9df16f0c9d1b22_66c890177ca4688e94a34cbe_blog-thumbnail-5.jpeg)

### Transform Your Idea Into Reality

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.

*   Writing UX copies can be a little frustrating and confusing
*   sometimes we are unsure about how to get the right word
*   The plugin is called the Ghost UXWriter and has a set of UX copies cataloged

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice.

#### Transform Your Idea Into Reality

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.
