---
f_featured: true
f_publication-link: https://www.youtube.com
title: Ut Amet Magna
f_publication-summary: |-
  Maecenas euismod sapien eu arcu convallis, vitae vestibulum ipsum maximus.
  Praesent nec orci at nulla consequat congue ut non arcu.
  Sed auctor augue id tellus lacinia, nec ultricies est fermentum.
  Vestibulum ante ipsum primis in faucibus orci luct
slug: ut-amet-magna
f_main-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cf5c75a4d1a136c37b049a_image10.jpeg
  alt: null
updated-on: '2024-08-28T19:24:48.902Z'
created-on: '2024-08-28T17:20:54.883Z'
published-on: '2024-08-28T19:25:47.028Z'
f_category: Publications
layout: '[resources].html'
tags: resources
---

Praesent nec orci at nulla consequat congue ut non arcu.
--------------------------------------------------------

Praesent nec orci at nulla consequat congue ut non arcu.

### Praesent nec orci at nulla consequat congue ut non arcu.

> Fusce aliquet turpis at orci bibendum, non convallis justo tempor.

Sed auctor augue id tellus lacinia, nec ultricies est fermentum. Maecenas euismod sapien eu arcu convallis, vitae vestibulum ipsum maximus. Maecenas euismod sapien eu arcu convallis, vitae vestibulum ipsum maximus.

Cras sit amet velit id nulla tempus dictum sit amet eu nisi. Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.
---------------------------------------------------------------------------------------

Sed auctor augue id tellus lacinia, nec ultricies est fermentum.

### Lorem ipsum dolor sit amet, consectetur adipiscing elit.

> Praesent nec orci at nulla consequat congue ut non arcu. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.

Sed auctor augue id tellus lacinia, nec ultricies est fermentum.

Cras sit amet velit id nulla tempus dictum sit amet eu nisi. Fusce aliquet turpis at orci bibendum, non convallis justo tempor. Maecenas euismod sapien eu arcu convallis, vitae vestibulum ipsum maximus.
