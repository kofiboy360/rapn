---
f_featured: false
f_publication-link: https://twitter.com
title: Tempor
f_publication-summary: nas euismod sapien eu arcu convallis, vitae vestibulum ipsum
f_main-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cf5c75a4d1a136c37b04a0_image19.jpeg
  alt: null
slug: tempor
updated-on: '2024-08-28T19:24:42.510Z'
created-on: '2024-08-28T17:20:54.898Z'
published-on: '2024-08-28T19:25:47.028Z'
f_category: Publications
layout: '[resources].html'
tags: resources
---

Cras sit amet velit id nulla tempus dictum sit amet eu nisi.
------------------------------------------------------------

Integer rutrum ante et nunc venenatis, id ultricies risus ultricies. Vivamus vitae arcu vel velit efficitur vestibulum vel in purus.

### Integer rutrum ante et nunc venenatis, id ultricies risus ultricies.

> Fusce aliquet turpis at orci bibendum, non convallis justo tempor. Praesent nec orci at nulla consequat congue ut non arcu.

Integer rutrum ante et nunc venenatis, id ultricies risus ultricies. Fusce aliquet turpis at orci bibendum, non convallis justo tempor. Praesent nec orci at nulla consequat congue ut non arcu.

Donec eu felis at libero consequat sagittis a et urna. Vivamus vitae arcu vel velit efficitur vestibulum vel in purus.
