---
f_featured: true
title: Our internal process and longterm vision
f_post-summary: >-
  Authentic leadership critical for business growth – Telecel’s GM for
  Commercial Operations
slug: our-internal-process-and-longerm-vision
f_main-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cb5b1e70d8568ff4742359_Awards.jpg
  alt: null
f_thumbnail-image:
  url: >-
    https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66cb5b1e70d8568ff4742359_Awards.jpg
  alt: null
updated-on: '2024-08-25T16:26:11.774Z'
created-on: '2021-07-15T15:54:50.693Z'
published-on: '2024-08-25T16:30:03.062Z'
f_author-details: cms/author/selby-johnson.md
f_alt-text-for-image: People playing in office
layout: '[blogs-news].html'
tags: blogs-news
---

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice and tone for error messages.

Transform Your Idea Into Reality
--------------------------------

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice.

![](https://uploads-ssl.webflow.com/66c890177ca4688e94a34cb3/66cb5b23c1be2dc443cf85a1_66c890177ca4688e94a34cbb_blog-thumbnail-2.jpeg)

### Transform Your Idea Into Reality

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.

*   Writing UX copies can be a little frustrating and confusing
*   sometimes we are unsure about how to get the right word
*   The plugin is called the Ghost UXWriter and has a set of UX copies cataloged

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged and categorized with a voice and tone variation ranging from plain, casual to playful. The intention to build this Figma plugin originated from our Medium blog post, ‘Designing voice.

#### Transform Your Idea Into Reality

Writing UX copies can be a little frustrating and confusing, and sometimes we are unsure about how to get the right word. To crack the code for the UX copies, we at Zeta Design wanted to build a Figma plugin for the larger design community. The plugin is called the Ghost UXWriter and has a set of UX copies cataloged.
