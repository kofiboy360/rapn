---
f_start-date-time: '2024-09-18T00:00:00.000Z'
f_end-date-time: '2024-09-19T00:00:00.000Z'
f_registeration-link: https://tally.so/r/nWYeee
title: Africa Food Regulatory & Quality Assurance Conference
f_location: Peninsula Golf Resort, Akosombo
f_short-description: Africa Food Regulatory & Quality Assurance Conference
slug: africa-food-regulatory-quality-assurance-conference
updated-on: '2024-09-13T18:20:24.965Z'
created-on: '2024-08-28T12:46:57.327Z'
published-on: '2024-09-13T23:24:30.750Z'
f_event-type: Event
f_price: '350'
layout: '[event].html'
tags: event
---

### **MEET OUR SPEAKERS**

‍

##### 1. **Dr. Aina Stephen** Olugbenga

_\-_ Deputy Director -

National Agency for Food

and Drug Administration and

Control (NAFDAC)

##### **2\. Prof. Alex Dodoo**

_\-_ Executive Director

Ghana Standards Authority

President- African

Organization for Standards

##### **3\. Yunusa Mohammed**

\- Deputy Director-Standards

Organization of Nigeria

‍

### Date: Sept 18-19, 2024

### Venue: Peninsula Golf Resort, Akosombo

‍

![__wf_reserved_inherit](https://cdn.prod.website-files.com/66c890177ca4688e94a34cb3/66e421613e3e1ced380de7d6_66e4215ae6b7a464772944cd_WhatsApp%2520Image%25202024-09-12%2520at%252015.00.02_8b8a98f9.jpeg)

Africa Food Regulatory & Quality Assurance Conference
